import React from "react";
import Hero from "../components/Hero";
import Banner from "../components/Banner";
import Services from "../components/Services";
import { Link } from "react-router-dom";
import FeaturesRooms from "../components/Features";

export default function Home() {
  return (
    <>
      <Hero>
        <Banner
          title="Where does it come from"
          subtitle="Contrary to popular belief, Lorem Ipsum is not simply random text"
        >
          <Link to="/rooms" className="btn-primary">
            Our Rooms
          </Link>
        </Banner>
      </Hero>
      <Services />
      <FeaturesRooms />
    </>
  );
}
